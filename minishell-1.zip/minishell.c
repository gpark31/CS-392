/*******************************************************************************
 * Name        : minishell.c
 * Author      : GaYoung Park, Luca Pieples
 * Date        : 4/13/2021
 * Description : 
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <assert.h>
#include <limits.h>
#include <sys/types.h>
#include <pwd.h>
#include <stdbool.h>
#include <setjmp.h>

#define BRIGHTBLUE "\x1b[34;1m"
#define DEFAULT "\x1b[0m"

volatile sig_atomic_t interrupted = false;
pid_t pid;
jmp_buf here;
bool inputing;

void catch_signal() {
    interrupted = true;
    printf("\n");
    if(inputing) {
        siglongjmp(here,1);
    }
}

int print_cwd() {
	char buffer[PATH_MAX];
	if (getcwd(buffer, sizeof(buffer)) == NULL) {
       fprintf(stderr, "Error: Cannot get current working directory. %s.\n", strerror(errno));
	   return EXIT_FAILURE;
	}
	printf("[%s%s%s]$ ", BRIGHTBLUE, buffer, DEFAULT);
	return EXIT_SUCCESS;
}

char* get_input() {
	char static input[65536];
    memset(input, 0, sizeof(input));
	if (read(0, input , sizeof(input)) == -1) {
        if(!interrupted) {
	        fprintf(stderr, "Error: Failed to read from stdin. %s.\n", strerror(errno));
        }
 		return NULL;
    }
	return input;
}

int main(int argc, char *argv[]) {
	struct sigaction action;
	memset(&action, 0, sizeof(struct sigaction));
	action.sa_handler = catch_signal;
	action.sa_flags = SA_RESTART;
	if (sigaction(SIGINT, &action, NULL) == -1){
		fprintf(stderr, "Error: Cannot register signal handler. %s.\n", strerror(errno));
        return EXIT_FAILURE;
	}
    sigsetjmp(here,1);
	while(true) {
        interrupted = false;
		if (print_cwd() == EXIT_FAILURE) {
			return EXIT_FAILURE;
		}
        fflush(stdout);
        char* input;
        inputing = true;
		input = get_input();
        inputing = false;
        if(!interrupted) {
            if (input == NULL) {
                return EXIT_FAILURE;
            }
            if(input[0] == '\n' || input[0] == '\0') {
               continue;
            }
            int i = 0;
            int j = 0;
            while(input[i] == ' ') {
                i++;
            }
            char cmd[65536];
            memset(cmd, 0, sizeof(cmd));
            while((input[i] != ' ') && (input[i] != '\n') && (input[i] != '\0')) {
                cmd[j] = input[i];
                i++;
                j++;
            }
            if(strcmp(cmd, "cd") == 0) {
                j = 0;
                while(input[i] == ' ') {
                    i++;
                }
                char arg[65536];
                memset(arg, 0, sizeof(arg));
                while((input[i] != ' ') && (input[i] != '\n') && (input[i] != '\0')) {
                    arg[j] = input[i];
                    i++;
                    j++;
                }
                while(input[i] == ' ') {
                    i++;
                }
                if(input[i] == 10) {
                    char* dir;
                    if(arg[0] == '\0' || (arg[0] == '~' && arg[1] == '\0')) {
                        struct passwd* pwuid_struct;
                        if((pwuid_struct = getpwuid(getuid())) == NULL) {
                            fprintf(stderr,"Cannot get passwd entry. %s.\n", strerror(errno));
                        }
                        else {
                            dir = pwuid_struct->pw_dir;
                        }
                    }
                    else {
                        dir = arg;
                    }
                    if (chdir(dir) == -1) {
                        fprintf(stderr,"Error: Cannot change directory to '%s'. %s.\n", dir, strerror(errno));
                    }
                }
                else {
                    printf("Error: Too many arguments to cd.\n");
                }
            }
            else if(strcmp(cmd, "exit") == 0) {
                return EXIT_SUCCESS;
            }
            else {
                int k = i, count = 0;
                bool space = true;
                while(input[k] != '\0') {
                    if(space && input[k] != ' ' && input[k] != '\n' && input[k] != '\0') {
                        space = false;
                        count++;
                    }
                    else if(!space && input[k] == ' ') {
                        space = true;
                    }
                    k++;
                }
                char* args[count + 2];
                args[0] = cmd;
                args[count + 1] = NULL;
                for(int m = 1; m < count + 1; m++) {
                    if((args[m] = (char*) calloc(65536, sizeof(char))) == NULL) {
                        fprintf(stderr, "Error: calloc() failed. %s.\n", strerror(errno));
                    }
                }
                space = true;
                int l = 0, new_count = 0;
                while(input[i] != '\0') {
                    if(input[i] != ' ' && input[i] != '\n' && input[i] != '\0') {
                        if(space) {
                            l = 0;
                            space = false;
                            new_count++;
                        }
                        if(new_count > count) {
                            break;
                        }
                        args[new_count][l] = input[i];
                        l++;
                    }
                    else if(!space && (input[i] == ' ' || input[i] == '\n' || input[i] == '\0')) {
                        space = true;
                    }
                    i++;
                }
                if((pid = fork()) < 0) {
                    fprintf(stderr, "Error: fork() failed. %s.\n", strerror(errno));
                    for(int m = 1; m < count + 1; m++) {
                        free(args[m]);
                    }
                }
                if(pid == 0) {
                    if (execvp(args[0], args) < 0) {
                        fprintf(stderr, "Error: exec() failed. %s.\n",  strerror(errno));
                        for(int m = 1; m < count + 1; m++) {
                            free(args[m]);
                        }
                        return EXIT_FAILURE;
                    }
                }
                else if(pid > 0) {
                    for(int m = 1; m < count + 1; m++) {
                        free(args[m]);
                    }
                    pid_t id;
                    if((id = wait(NULL)) < 0 && !interrupted) {
                        fprintf(stderr, "Error: wait() failed. %s.\n", strerror(errno));
                    }
                }
            }
        }
	}
}