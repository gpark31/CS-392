/*******************************************************************************
 * Name        : mtsieve.c
 * Author      : GaYoung Park, Luca Pieples
 * Date        : 4/23/2021
 * Description : 
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <stdio.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <getopt.h>
#include <ctype.h>
#include <sys/sysinfo.h>
#include <pthread.h>
#include <stdbool.h>
#include <math.h>

typedef struct arg_struct {
    int start;
    int end;
} thread_args;

int total_count = 0;
pthread_mutex_t lock;

bool two_threes(int num){
    int count = 0;
    while(num > 0){
        if(num%10 == 3){
            count++;
            if(count >= 2){
                return true;
            }
        }
        num = num/10;
    }
    return false;
}

void *sieve(void *ptr){
    thread_args args = *(thread_args *)ptr;
    int n = sqrt(args.end);
    bool primes[n + 1];
    int count = n - 1;
    memset(primes, true, sizeof(primes));
    for(int i = 2; i <= sqrt(n); i++){
        if(primes[i]){
            for(int j = i * i; j <= n; j += i){
                if(primes[j]){
                    count--;
                    primes[j] = false;
                }
            }
        }
    }
    primes[0] = false;
    primes[1] = false;
    int low_primes[count];
    int current = 0;
    for(int i = 2; i < n+1; i++){
        if(primes[i]){
            low_primes[current] = i;
            current++; 
        }
    }
    int length = args.end - args.start + 1;
    bool *high_primes;
    if((high_primes = malloc(sizeof(int)*length)) == NULL) {
        fprintf(stderr, "Error: malloc() failed. %s.\n", strerror(errno));
    }
    memset(high_primes, true, length * sizeof *high_primes);
    for(int p = 0; p < count; p++){
        int i = ceil((double)args.start/low_primes[p])*low_primes[p] -args.start; //(the first index that contains a multiple of 2 )
        if(args.start <= low_primes[p]){
            i = i + low_primes[p];
        }
        for(int j = i; j < length; j=j+low_primes[p]){
            if(high_primes[j] && (j+args.start)%low_primes[p] == 0){
                high_primes[j] = false;
            }
        }
    }
    int temp_count = 0;
    for(int i = 0; i < length; i++){
        if(high_primes[i]){
            if(two_threes(i+args.start)){
                temp_count++;
            }
        }
    }
    free(high_primes);
    if(pthread_mutex_lock(&lock) != 0) {
        fprintf(stderr, "Warning: Cannot lock mutex. %s.\n", strerror(errno));
    }
    total_count += temp_count;
    if(pthread_mutex_unlock(&lock) != 0) {
        fprintf(stderr, "Warning: Cannot unlock mutex. %s.\n", strerror(errno));
    }
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    int opt;
	int start_value_flag = 0; 
    int end_value_flag = 0; 
    int thread_flag = 0;
    int start_value, end_value, num_threads;
    opterr = 0;
	//Parse with getopt
	while((opt = getopt(argc, argv, "s:e:t:")) != -1)
    {
        switch(opt)
        {
            case 's':
                for(int i = 0; i < strlen(optarg); i++) {
                    if(!isdigit(optarg[i])){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }      
                if(atoi(optarg) > INT_MAX){
                    fprintf(stderr, "Error: Integer overflow for parameter '-%c'.\n", atoi(optarg));
                    return EXIT_FAILURE;
                }
                start_value = atoi(optarg);
                start_value_flag = 1;
                break;
            case 'e':
               for(int i = 0; i < strlen(optarg); i++) {
                    if(!isdigit(optarg[i])){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }     
                if(atoi(optarg) > INT_MAX){
                    fprintf(stderr, "Error: Integer overflow for parameter '-%c'.\n", atoi(optarg));
                    return EXIT_FAILURE;
                }
                end_value = atoi(optarg);
            	end_value_flag = 1;
                break;
            case 't':
                for(int i = 0; i < strlen(optarg); i++) {
                    if(!isdigit(optarg[i])){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }     
                if(atol(optarg) > INT_MAX){
                    fprintf(stderr, "Error: Integer overflow for parameter '-t'.\n");
                    return EXIT_FAILURE;
                }
                num_threads = atoi(optarg);
                thread_flag = 1;
                break;
			case '?':
                if (optopt == 'e' || optopt == 's' || optopt == 't') {
                    fprintf(stderr, "Error: Option -%c requires an argument.\n", optopt);
                } else if (isprint(optopt)) {
                    fprintf(stderr, "Error: Unknown option '-%c'.\n", optopt);
                } else {
                    fprintf(stderr, "Error: Unknown option character '\\x%x'.\n",
                    optopt);
                }
                return EXIT_FAILURE;
        }
    }
    // checks number of arguments
    if (argc <= 1) {
        printf("Usage: ./mtsieve -s <starting value> -e <ending value> -t <num threads>\n");
        return EXIT_FAILURE;
    }
    if (argc > 4) {
        printf("Error: Non-option argument '%s' supplied.\n", argv[4]);
        return EXIT_FAILURE;
    }
    if (argc > 1 && argv[1][0] != '-') {
        printf("Error: Non-option argument '%s' supplied.\n", argv[1]);
        return EXIT_FAILURE;
    }
    if (argc > 2 && argv[2][0] != '-') {
        printf("Error: Non-option argument '%s' supplied.\n", argv[2]);
        return EXIT_FAILURE;
    }
    if (argc > 3 && argv[3][0] != '-') {
        printf("Error: Non-option argument '%s' supplied.\n", argv[3]);
        return EXIT_FAILURE;
    }
    if(start_value_flag == 0){
        printf("Error: Required argument <starting value> is missing.\n");
        return EXIT_FAILURE;
	}
	if(start_value < 2){
        printf("Error: Starting value must be >= 2.\n");
        return EXIT_FAILURE;
	}
    if(end_value_flag == 0){
        printf("Error: Required argument <ending value> is missing.\n");
        return EXIT_FAILURE;
	}
	if(end_value < 2) {
		printf("Error: Ending value must be >= 2.\n");
		return EXIT_FAILURE;
	}
    if(end_value < start_value){
        printf("Error: Ending value must be >= starting value.\n");
		return EXIT_FAILURE;
    }
    if(thread_flag == 0){
        printf("Error: Required argument <num threads> is missing.\n");
        return EXIT_FAILURE;
	}
    if(num_threads < 1){
        printf("Error: Number of threads cannot be less than 1.\n");
		return EXIT_FAILURE;
    }
    if(num_threads > 2*get_nprocs()){
        printf("Error: Number of threads cannot exceed twice the number of processors(%d).\n", get_nprocs());
		return EXIT_FAILURE;
    }

    printf("Finding all prime numbers between %d and %d.\n", start_value, end_value);

    int count = end_value - start_value + 1;
    if(num_threads > count) {
        num_threads = count;
    }

    pthread_t threads[num_threads];
    thread_args targs[num_threads];
    int offset = -1;

    for(int i = 0; i < num_threads; i++) {
        offset++;
        targs[i].start = start_value+offset;
        offset = offset + (count/num_threads)-1;
        if(count%num_threads > i) {
            offset++;
        }
        targs[i].end = start_value+offset; //no safety
        int retval;
        if ((retval = pthread_create(&threads[i], NULL, sieve, &targs[i])) != 0) {
            fprintf(stderr, "Error: Cannot create thread %d. %s.\n", (i+1), strerror(retval));
            return EXIT_FAILURE;
        }
    }

    for (int i = 0; i < num_threads; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            fprintf(stderr, "Warning: Thread %d did not join properly.\n", i + 1);
        }
    }

    int retval;
    if ((retval = pthread_mutex_destroy(&lock)) != 0) {
        fprintf(stderr, "Error: Cannot destroy mutex. %s.\n", strerror(retval));
        return EXIT_FAILURE;
    }

    if(num_threads == 1) {
        printf("%d segment:\n", num_threads);
    }
    else {
        printf("%d segments:\n", num_threads);
    }
    for(int i = 0; i < num_threads; i++) {
        printf("   [%d, %d]\n", targs[i].start, targs[i].end);
    }

    printf("Total primes between %d and %d with two or more '3' digits: %d\n", start_value, end_value, total_count);

    return EXIT_SUCCESS;
}