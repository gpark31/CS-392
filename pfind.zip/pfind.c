/*******************************************************************************
 * Name        : pfind.c
 * Author      : GaYoung Park, Luca Pieples
 * Date        : 3/16/2021
 * Description : pfind implementation.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <stdio.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <getopt.h>
           
void usage() {
	printf("Usage: ./pfind -d <directory> -p <permissions string> [-h]\n");
}

int pfind(DIR *dir, char path[], int perms) {
    struct dirent *entry;
    struct stat sb;
    char full_filename[PATH_MAX+1];
    size_t pathlen = 0;

    // Set the initial character to the NULL byte.
    // If the path is root '/', you can now take the strlen of a properly
    // terminated empty string.
    full_filename[0] = '\0';
    if (strcmp(path, "/")) {
        // If path is not the root - '/', then ...

        // If there is no NULL byte among the first n bytes of path,
        // the full_filename will not be terminated. So, copy up to and
        // including PATH_MAX characters.
        strncpy(full_filename, path, PATH_MAX);
    }
    // Add + 1 for the trailing '/' that we're going to add.
    pathlen = strlen(full_filename) + 1;
    full_filename[pathlen - 1] = '/';
    full_filename[pathlen] = '\0';

    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 ||
            strcmp(entry->d_name, "..") == 0) {
            continue;
        }
        strncpy(full_filename + pathlen, entry->d_name, PATH_MAX - pathlen);
        if (lstat(full_filename, &sb) < 0) {
            fprintf(stderr, "Error: Cannot stat file '%s'. %s.\n",
                    full_filename, strerror(errno));
            continue;
        }
        if (entry->d_type == DT_DIR) {
            struct stat statbuf;
            if (lstat(full_filename, &statbuf) < 0) {
                fprintf(stderr, "Error: Cannot stat '%s'. %s.\n",
                        full_filename, strerror(errno));
                return EXIT_FAILURE;
            }
            else if ((statbuf.st_mode & 1023) == perms) {
                printf("%s\n", full_filename);
            }
            DIR *dir2;
            if ((dir2 = opendir(full_filename)) == NULL) {
                fprintf(stderr, "Error: Cannot open directory '%s'. %s.\n",
                        full_filename, strerror(errno));
                return EXIT_FAILURE;
            }
            pfind(dir2, full_filename, perms);
            closedir(dir2);
        } else {
            struct stat statbuf;
            if (lstat(full_filename, &statbuf) < 0) {
                fprintf(stderr, "Error: Cannot stat '%s'. %s.\n",
                        full_filename, strerror(errno));
                return EXIT_FAILURE;
            }
            else if ((statbuf.st_mode & 1023) == perms) {
                printf("%s\n", full_filename);
            }
        }
    }
    return EXIT_SUCCESS;
}

int main(int argc, char *argv[]) {
    int opt;
	int direc_flag = 0; 
    int perm_flag = 0; 
    int help_flag = 0;
    char* directory;
    char* permissions;
	
	//Parse with getopt
	while((opt = getopt(argc, argv, ":hd:p:")) != -1)
    {
        switch(opt)
        {
            case 'd':
                directory = optarg;
                direc_flag = 1;
                break;
            case 'h':
            	help_flag = 1;
                break;
            case 'p':
                permissions = optarg;
                perm_flag = 1;
                break;
			case '?':
			  	printf("Error: Unknown option '-%c' received.\n", optopt);
                return EXIT_FAILURE;
        }
    }
    //check if both -d and -p flags are present
    if(help_flag == 1 || argc == 1) {
        usage();
        return EXIT_FAILURE;
    }
	if(direc_flag == 0) {
		printf("Error: Required argument -d <directory> not found.\n");
		return EXIT_FAILURE;
	}
	if(perm_flag == 0) {
		printf("Error: Required argument -p <permissions string> not found.\n");
		return EXIT_FAILURE;

	}
    // checks number of arguments (Error not specified in the spec)
	if (argc != 5) {
        usage();
        return EXIT_FAILURE;
    }

    //TODO look here again!!

	//check path to see if a file exists
	struct stat statbuf;
    if (stat(directory, &statbuf)) {
        fprintf(stderr, "Error: Cannot stat '%s'. %s.\n", directory,
                strerror(errno));
        return EXIT_FAILURE;
    }

	//check can open directory
    char path[PATH_MAX];
    if (realpath(directory, path) == NULL) {
        fprintf(stderr, "Error: Cannot get full path of file '%s'. %s.\n",
                directory, strerror(errno));
        return EXIT_FAILURE;
    }

    DIR *dir;
    if ((dir = opendir(path)) == NULL) {
        fprintf(stderr, "Error: Cannot open directory '%s'. %s.\n",
                path, strerror(errno));
        return EXIT_FAILURE;
    }
	//check if permissions is composed of correct strings
    int perms = 0;
	if(sizeof(permissions) == 8) {
		for(int i = 0; i < 9; i++) {
            switch(permissions[i]){
                case '-':
                    break;
                case 'r':
                    switch(i) {
                        case 0:
                            perms = perms + 256;
                            break;
                        case 3:
                            perms = perms + 32;
                            break;
                        case 6:
                            perms = perms + 4;
                            break;
                        default:
                            printf("Error: Permissions string '%s' is invalid.\n", permissions);
                            return EXIT_FAILURE;
                            break;
                    }
                    break;
                case 'w':
                    switch(i) {
                        case 1:
                            perms = perms + 128;
                            break;
                        case 4:
                            perms = perms + 16;
                            break;
                        case 7:
                            perms = perms + 2;
                            break;
                        default:
                            printf("Error: Permissions string '%s' is invalid.\n", permissions);
                            return EXIT_FAILURE;
                            break;
                    }
                    break;
                case 'x':
                    switch(i) {
                        case 2:
                            perms = perms + 64;
                            break;
                        case 5:
                            perms = perms + 8;
                            break;
                        case 8:
                            perms = perms + 1;
                            break;
                        default:
                            printf("Error: Permissions string '%s' is invalid.\n", permissions);
                            return EXIT_FAILURE;
                            break;
                    }
                    break;
                default:
                    printf("Error: Permissions string '%s' is invalid.\n", permissions);
					return EXIT_FAILURE;
                    break;
            }
		}
	}
	else{
		printf("Error: Permissions string '%s' is invalid.\n", permissions);
		return EXIT_FAILURE;
	}

    int i = pfind(dir, path, perms);

    closedir(dir);
    return i;
}
