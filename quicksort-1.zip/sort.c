/*******************************************************************************
 * Name        : sort.c
 * Author      : GaYoung Park, Luca Pieples
 * Date        : 3/2/2021
 * Description : Uses quicksort to sort a file of either ints, doubles, or
 *               strings.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "quicksort.h"

#define MAX_STRLEN     64 // Not including '\0'
#define MAX_ELEMENTS 1024

typedef enum {
    STRING,
    INT,
    DOUBLE
} elem_t;

void usage() {
    printf("Usage: ./sort [-i|-d] filename\n");
    printf("   -i: Specifies the file contains ints.\n");
    printf("   -d: Specifies the file contains double.\n");
    printf("   filename: The file to sort.\n");
    printf("   No flags defaults to sorting strings.\n");
}

/**
 * Reads data from filename into an already allocated 2D array of chars.
 * Exits the entire program if the file cannot be opened.
 */
size_t read_data(char *filename, char **data) {
    // Open the file.
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Error: Cannot open '%s'. %s.\n", filename,
                strerror(errno));
        free(data);
        exit(EXIT_FAILURE);
    }

    // Read in the data.
    size_t index = 0;
    char str[MAX_STRLEN + 2];
    char *eoln;
    while (fgets(str, MAX_STRLEN + 2, fp) != NULL) {
        eoln = strchr(str, '\n');
        if (eoln == NULL) {
            str[MAX_STRLEN] = '\0';
        } else {
            *eoln = '\0';
        }
        // Ignore blank lines.
        if (strlen(str) != 0) {
            data[index] = (char *)malloc((MAX_STRLEN + 1) * sizeof(char));
            strcpy(data[index++], str);
        }
    }

    // Close the file before returning from the function.
    fclose(fp);

    return index;
}

/**
 * Basic structure of sort.c:
 *
 * Parses args with getopt.
 * Opens input file for reading.
 * Allocates space in a char** for at least MAX_ELEMENTS strings to be stored,
 * where MAX_ELEMENTS is 1024.
 * Reads in the file
 * - For each line, allocates space in each index of the char** to store the
 *   line.
 * Closes the file, after reading in all the lines.
 * Calls quicksort based on type (int, double, string) supplied on the command
 * line.
 * Frees all data.
 * Ensures there are no memory leaks with valgrind. 
 */
int main(int argc, char **argv) {
    int opt;
	int intflag = 0, doubleflag = 0, fileflag = 0;
	
	//Parse with getopt
	while((opt = getopt(argc, argv, ":id")) != -1)
    {
        switch(opt)
        {
            case 'i':
                if(intflag == 1 || doubleflag == 1) {
            		printf("Error: Too many flags specified.\n");
            		return EXIT_FAILURE;
            	}
            	intflag = 1;
                break;
            case 'd':
            	if(intflag == 1 || doubleflag == 1) {
            		printf("Error: Too many flags specified.\n");
            		return EXIT_FAILURE;
            	}
            	else {
            		doubleflag = 1;
            	}
                break;
            case '?':
                printf("Error: Unknown option '-%c' received.\n", optopt);
                usage();
                return EXIT_FAILURE;
                break;
        }
    }
    // checks extra arguments
    int file_numb = 0;
    char* filename;
    for( ; optind < argc && *argv[optind] != '-'; optind++) {
        filename = argv[optind];
    	file_numb++;
        fileflag = 1;
    }
    if(fileflag == 0 && intflag == 0 && doubleflag == 0) {
    	usage();
        return EXIT_FAILURE;
    }
    if(fileflag == 0) {
    	printf("Error: No input file specified.\n");
    	return EXIT_FAILURE;
    }
    if(file_numb > 1) {
    	printf("Error: Too many files specified.\n");
    	return EXIT_FAILURE;
    }

    char **data = (char **)malloc(MAX_ELEMENTS * sizeof(char *));
    size_t len = read_data(filename, data);

    if(intflag == 1) {
        int *x = (int *)malloc(len * sizeof(int));
        for(int i = 0; i < len; i++) {
            x[i] = atoi(data[i]);
        }
        quicksort(x, len, sizeof(int), int_cmp);
        for(int i = 0; i < len; i++) {
            printf("%i\n", x[i]);
        }
        free(x);
    }
    else if(doubleflag == 1) {
        double *x = (double *)malloc(len * sizeof(double));
        for(int i = 0; i < len; i++) {
            char *ptr;
            x[i] = strtod(data[i], &ptr);
        }
        quicksort(x, len, sizeof(double), dbl_cmp);
        for(int i = 0; i < len; i++) {
            printf("%f\n", x[i]);
        }
        free(x);
    }
    else {
        quicksort(data, len, sizeof(char*), str_cmp);
        for(int i = 0; i < len; i++) {
            printf("%s\n", data[i]);
        }
    }

    for(int i = 0; i < len; i++) {
        free(data[i]);
    }
    free(data);

    return EXIT_SUCCESS;
}