/*******************************************************************************
 * Name        : spfind.c
 * Author      : GaYoung Park, Luca Pieples
 * Date        : 3/31/2021
 * Description : 
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <assert.h>


int main(int argc, char *argv[]) {
  if (argc == 1) {
    fprintf(stderr, "Usage: %s -d <directory> -p <permissions string> [-h]\n", argv[0]);
    return EXIT_FAILURE;
  }
  //pipe for pfind to sort 
  int pfind_sort[2];
  //pipe for parent to sort
  int parent_sort[2];

  if (pipe(pfind_sort) < 0) {
      fprintf(stderr, "Error: Cannot create pipe pfind_sort. %s.\n",strerror(errno));
      return EXIT_FAILURE;

  }
  if (pipe(parent_sort) < 0) {
    fprintf(stderr, "Error: Cannot create pipe parent_sort. %s.\n",strerror(errno));
    return EXIT_FAILURE;

  }
  pid_t pid[2];
  if ((pid[0] = fork()) == 0) {
    //pfind 
    close(pfind_sort[0]);
    dup2(pfind_sort[1], STDOUT_FILENO);
  
    //Close all unrelated file descriptors.
    close(parent_sort[0]);
    close(parent_sort[1]);

    //get pwd of pfind
    long n;
    if ((n = pathconf("pfind", _PC_PATH_MAX)) == -1){
      fprintf(stderr, "Error: pathconf failed. %s.\n",strerror(errno));
      return EXIT_FAILURE;
    }
    char *buffer = malloc(n * sizeof(*buffer));
    if (getcwd(buffer, n) == NULL){
      fprintf(stderr, "Error: getcwd failed. %s.\n",strerror(errno));
      return EXIT_FAILURE;
    }
    int openArray = strlen(buffer);
    buffer[openArray] = '/';
    buffer[openArray+1] = 'p';
    buffer[openArray+2] = 'f';
    buffer[openArray+3] = 'i';
    buffer[openArray+4] = 'n';
    buffer[openArray+5] = 'd';

    if(execlp(buffer, "pfind", argv[1], argv[2], argv[3], argv[4], NULL) < 0) {
      fprintf(stderr, "Error: pfind failed. %s.\n",strerror(errno));
      return EXIT_FAILURE;
    }
  }
  if((pid[1] = fork()) == 0) {
    //sort
    close(pfind_sort[1]);
    dup2(pfind_sort[0], STDIN_FILENO);
    close(parent_sort[0]);
    dup2(parent_sort[1], STDOUT_FILENO);
      if (execlp("sort", "sort", NULL) < 0) {
        fprintf(stderr, "Error: grep failed %s.\n", strerror(errno));
        return EXIT_FAILURE;
      }
  }
  close(parent_sort[1]);
  dup2(parent_sort[0], STDIN_FILENO);
  close(pfind_sort[0]);
  close(pfind_sort[1]);

  char buffer[4096];
  int counter = 0;
  while(1) {
    ssize_t count = read(STDIN_FILENO, buffer, sizeof(buffer));
    if(count == -1) {
      if (errno == EINTR){
        continue;
      }
      else {
        perror("read()");
        return EXIT_FAILURE;
      }
    } 
    else if(count == 0){
      break;
    } 
    else {
      write (STDOUT_FILENO, buffer, count);
      for( ssize_t x = 0; x < count; x++ ) {
        if( '\n' == buffer[x] || '\0' == buffer[x] ) {
          counter++;
        }
      }
    }
  }
  if(counter > 0 ){
    printf("Total matches: %d\n", counter);
  }
  close(parent_sort[0]);
  wait(NULL);
  wait(NULL);
  return EXIT_SUCCESS;
}